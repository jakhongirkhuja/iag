
## Aigent Test Version 0.22
** Added Social Login Auth
 
## Aigent Test Version 0.21
** Modified input prices

## Aigent Test Version 0.2

Modified logic of filter.

some changes (front vuew) : 

** filter max-width

** modal  zoom photo slider

** on click new window

** developer inserted into agents

## License

jakhongirkhuja.kholkhujaev@gmail.com
