<html>
<head>
  <title>Counter</title>
</head>

<body>
 @include('include')
</body>

</html>