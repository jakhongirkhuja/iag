<html>
<head>
  <title>Counter</title>
</head>

<body>
 <?php echo $__env->make('include', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

</html><?php /**PATH /var/www/resources/views/admin/index.blade.php ENDPATH**/ ?>