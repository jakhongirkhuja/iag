<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Iagent</title>
        <link rel="icon" type="image/ico" href="<?php echo e(asset('img/icon.ico')); ?>" />
        <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
        
    </head>
    <body >
        <div id="app" style="
        overflow-x: hidden;
    ">
            <app/>
           
        </div>
        <footer >
            <div class="footer">
                <div class="container">
                   
                    <div class="footer-body fx vertical_center ">
                        <div class="footer__each">
                            <h2>Остались вопросы?</h2>
                        </div>
                        <div class="footer__each">
                            <h3>Звоните или Пишите</h3>
                            <p class="fx vertical_center"><a href="tel:+998946121812" style="margin-right:1rem">+998 ( 94 ) 612-18-12</a> <a href="https://t.me/Bakers_Dozen"><img src="<?php echo e(asset('img/telegram.png')); ?>" width="32"></a> </p>
                        </div>
                       
                    </div>
                </div>
            </div>
            
        </footer>
        <style lang="scss" scoped>
            .footer{
                padding: 3rem 0;
                background: #f1f1f1;
            }
            .footer-body{
                justify-content: space-between;
            }
            .footer h2{
                font-size: 3rem;
                    color: black;
            }
            .footer h3{
                font-size: 1.5rem
            }
            .footer a{
                font-size: 1.2rem;
            }
        </style>
        <script src="<?php echo e(asset('js/app.js')); ?>"></script>
        <!-- Global site tag (gtag.js) - Google Analytics -->
        <script async src="https://www.googletagmanager.com/gtag/js?id=G-7CY9YCM3HK"></script>
        <script>
        window.dataLayer = window.dataLayer || [];
        function gtag(){dataLayer.push(arguments);}
        gtag('js', new Date());

        gtag('config', 'G-7CY9YCM3HK');
        </script>
    </body>
</html>
<?php /**PATH /var/www/resources/views/welcome.blade.php ENDPATH**/ ?>