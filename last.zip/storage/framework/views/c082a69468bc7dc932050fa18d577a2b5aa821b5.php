<?php if(Session::has('success')): ?>
            <p class="alert <?php echo e(Session::get('alert-class', 'alert-info')); ?>"><?php echo e(Session::get('success')); ?></p>
            <?php endif; ?>
            <?php if(isset($pars)): ?>
            <?php $__currentLoopData = $pars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $par): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div style="display: flex">
                    <div class="n" style="margin-right: 0.5rem; width: 250px;">
                        <?php echo e($par->city); ?> <?php echo e($par->id); ?>

                    </div>
                    <div class="n" style="margin-right: 0.5rem; width: 150px;">
                        <?php echo e($par->housingtype); ?>

                    </div>
                    <div class="reg" style="width: 200px; margin-right:0.5rem">
                        <?php echo e($par->region); ?>

                    </div>
                    <div class="url" style="overflow:hidden; width: 900px; height:20px;">
                        <a target="_blank" href="<?php echo e($par->url); ?>"><?php echo e($par->url); ?></a>
                    </div>
                </div>    
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            <div>

            </div>
            <br>
            <form method="post"  action="<?php echo e(route('import_excel')); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="site" value="2">
                <input type="file" name="excel">
                <input type="submit" value="Import Excel Uybor">
            </form>
            <form method="post" style="margin-top:1rem" action="<?php echo e(route('import_excel')); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="site" value="1">
                <input type="file" name="excel">
                <input type="submit" value="Import Excel OLX">
            </form>
            <div class="owner" style="margin-top:30px; display:flex;">
                <div>
                    <?php if(isset($estate)): ?>
                    <div style="margin-bottom:1rem">
                        <?php echo e($count); ?>

                    </div>
                            <?php $__currentLoopData = $estate; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div style="display: flex">
                                    <div style="margin-right: 0.4rem">
                                        <?php echo e($item->id); ?>: 
                                    </div>
                                    <div>
                                        <a href="<?php echo e($item->url); ?>"><?php echo e($item->title); ?></a>
                                    </div>
                                    <div>
                                        <?php echo e($item->owner()->first()->number); ?>

                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php echo e($estate->links('vendor.pagination.semantic-ui')); ?>

                    <?php endif; ?>
                </div>
                <div>
                    <?php if(isset($owner)): ?>
                    <div style="margin-bottom:1rem">
                        <?php echo e($counto); ?>

                    </div>
                    <?php $__currentLoopData = $owner; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $own): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div style="display: flex;">
                            <div>
                                <?php echo e($own->number); ?> - <?php echo e($own->name); ?> - <?php echo e($own->announcement); ?> : 
                            </div>
                            <?php if(count($own->estates()->get())>0): ?>
                                <span>| Ссылки: </span>
                                <?php $__currentLoopData = $own->estates()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$w): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <a href="<?php echo e($w->url); ?>"><?php echo e($k+1); ?>- </a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php echo e($owner->links('vendor.pagination.semantic-ui')); ?>

                <?php endif; ?>
                </div>
                
                
            </div>



            <a href="<?php echo e(route('redirectauth',['name'=>'github'])); ?>" >GITHUB</a>
            <a href="<?php echo e(route('redirectauth',['name'=>'telegram'])); ?>">Telegram</a>
            <a href="<?php echo e(route('redirectauth',['name'=>'google'])); ?>">Google</a>
            <a href="<?php echo e(route('redirectauth',['name'=>'facebook'])); ?>">facebook</a><?php /**PATH /var/www/resources/views/include.blade.php ENDPATH**/ ?>